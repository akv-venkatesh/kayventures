export const psw_vis = ()=> dispatch => {
    dispatch({
        type: 'SET_PSW_ViS',
    });
};