export const video_vis = ()=> dispatch => {
    dispatch({
        type: 'SET_VIDEO_ViS',
    });
};