export const setHeaderType = ()=> dispatch => {
    dispatch({
        type: 'SET_HEADER_TYPE',
    });
};